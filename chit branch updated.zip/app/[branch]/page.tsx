"use client";
import Chit_Enrollment from './enrollment';

export default function App() {
  return (
    <main>
      <section>
        <Chit_Enrollment />
      </section>
    </main>
  );
}
