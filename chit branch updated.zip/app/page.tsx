"use client";
import Chit_Enrollment from './root';

export default function App() {
  return (
    <main>
      <section>
        <Chit_Enrollment />
      </section>
    </main>
  );
}
